"""
Django project package.
"""
