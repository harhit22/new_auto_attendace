# Detection app __init__
