"""Analytics models - empty for now."""
# No models needed for analytics app
