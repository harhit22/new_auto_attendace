"""
Users app - User and Department management.
"""
default_app_config = 'apps.users.apps.UsersConfig'
