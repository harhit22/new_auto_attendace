"""
Faces app - Face images and embeddings management.
"""
default_app_config = 'apps.faces.apps.FacesConfig'
