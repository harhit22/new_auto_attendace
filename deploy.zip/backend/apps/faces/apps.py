"""
Faces app configuration.
"""
from django.apps import AppConfig


class FacesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.faces'
    verbose_name = 'Face Recognition'
