"""
Core app - shared utilities, base models, and middleware.
"""
default_app_config = 'core.apps.CoreConfig'
