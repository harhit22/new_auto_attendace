"""Sync app - Offline-first synchronization."""
default_app_config = 'apps.sync.apps.SyncConfig'
