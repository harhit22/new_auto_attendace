"""
Authentication app - JWT authentication and token management.
"""
default_app_config = 'apps.authentication.apps.AuthenticationConfig'
