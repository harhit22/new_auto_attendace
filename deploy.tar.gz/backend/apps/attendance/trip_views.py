"""
Trip API Views
Handles the complete trip workflow: Driver check-in -> Helper login -> Vehicle capture -> Checkout
"""
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.parsers import MultiPartParser, JSONParser
from django.utils import timezone
from django.shortcuts import get_object_or_404
import numpy as np

from core.models import (
    Organization, SaaSEmployee, Trip, VehicleComplianceRecord, 
    LoginDetectionResult, CustomYoloModel
)
from apps.detection.compliance_rules import check_full_compliance


class TripViewSet(viewsets.ViewSet):
    """
    Trip workflow API:
    
    CHECK-IN FLOW:
    1. POST /trips/driver-checkin/ - Driver verifies face, creates Trip
    2. POST /trips/{id}/helper-checkin/ - Helper verifies face (optional)
    3. POST /trips/{id}/skip-helper/ - Skip helper
    4. POST /trips/{id}/vehicle-checkin/ - Capture vehicle, run YOLO compliance
    
    CHECK-OUT FLOW:
    5. POST /trips/{id}/driver-checkout/ - Driver verifies face
    6. POST /trips/{id}/helper-checkout/ - Helper verifies face
    7. POST /trips/{id}/vehicle-checkout/ - Vehicle compliance, complete trip
    """
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, JSONParser]
    
    def list(self, request):
        """List trips for an organization with all image URLs"""
        org_id = request.query_params.get('organization_id')
        if not org_id:
            return Response({'error': 'organization_id required'}, status=400)
        
        trips = Trip.objects.filter(organization_id=org_id).select_related(
            'driver', 'helper',
            'checkin_driver_detection', 'checkin_helper_detection', 'checkin_vehicle',
            'checkout_driver_detection', 'checkout_helper_detection', 'checkout_vehicle'
        ).order_by('-date', '-checkin_time')[:50]
        
        def get_image_url(detection):
            if detection and detection.frame_image:
                return detection.frame_image.url
            return None
        
        def get_vehicle_image_url(vehicle):
            if vehicle and vehicle.vehicle_image:
                return vehicle.vehicle_image.url
            return None
        
        data = []
        for trip in trips:
            data.append({
                'id': str(trip.id),
                'date': str(trip.date),
                'driver': {
                    'id': trip.driver.employee_id,
                    'name': trip.driver.full_name
                },
                'helper': {
                    'id': trip.helper.employee_id,
                    'name': trip.helper.full_name
                } if trip.helper else None,
                'helper_skipped': trip.helper_skipped,
                'status': trip.status,
                'checkin_time': trip.checkin_time.isoformat() if trip.checkin_time else None,
                'checkout_time': trip.checkout_time.isoformat() if trip.checkout_time else None,
                'checkin_compliance_passed': trip.checkin_compliance_passed,
                'checkout_compliance_passed': trip.checkout_compliance_passed,
                'work_duration': str(trip.work_duration) if trip.work_duration else None,
                # Check-in images
                'checkin_driver_image': get_image_url(trip.checkin_driver_detection),
                'checkin_helper_image': get_image_url(trip.checkin_helper_detection),
                'checkin_vehicle_image': get_vehicle_image_url(trip.checkin_vehicle),
                'checkin_vehicle_detections': trip.checkin_vehicle.detections if trip.checkin_vehicle else None,
                # Check-out images
                'checkout_driver_image': get_image_url(trip.checkout_driver_detection),
                'checkout_helper_image': get_image_url(trip.checkout_helper_detection),
                'checkout_vehicle_image': get_vehicle_image_url(trip.checkout_vehicle),
                'checkout_vehicle_detections': trip.checkout_vehicle.detections if trip.checkout_vehicle else None,
            })
        
        return Response({'trips': data})

    @action(detail=False, methods=['get'], url_path='active-trip')
    def active_trip(self, request):
        """
        Get the active trip for a driver.
        GET /trips/active-trip/?org_code=XXX&employee_id=YYY
        """
        org_code = request.query_params.get('org_code')
        employee_id = request.query_params.get('employee_id')
        
        if not org_code or not employee_id:
            return Response({'error': 'org_code and employee_id required'}, status=400)
            
        try:
            # Find trips that are NOT completed
            trip = Trip.objects.filter(
                organization__org_code=org_code,
                driver__employee_id=employee_id
            ).exclude(status='completed').order_by('-date', '-checkin_time').first()
            
            if trip:
                return Response({
                    'found': True,
                    'trip_id': str(trip.id),
                    'status': trip.status,
                    'helper_skipped': trip.helper_skipped,
                    'has_helper': bool(trip.helper)
                })
            
            return Response({'found': False, 'message': 'No active trip found'})
            
        except Exception as e:
            return Response({'error': str(e)}, status=500)
    
    @action(detail=False, methods=['post'], url_path='driver-checkin')
    def driver_checkin(self, request):
        """
        Step 1: Driver checks in with face verification.
        Creates a new Trip record.
        
        POST /trips/driver-checkin/
        Body: org_code, employee_id, image (face photo)
        """
        org_code = request.data.get('org_code', '').upper().strip()
        employee_id = request.data.get('employee_id', '').strip()
        image_file = request.FILES.get('image')
        
        if not org_code or not employee_id or not image_file:
            return Response({'error': 'org_code, employee_id, and image required'}, status=400)
        
        try:
            org = Organization.objects.get(org_code=org_code, is_active=True)
        except Organization.DoesNotExist:
            return Response({'error': 'Organization not found'}, status=404)
        
        try:
            driver = SaaSEmployee.objects.get(
                organization=org, 
                employee_id=employee_id, 
                status='active'
            )
        except SaaSEmployee.DoesNotExist:
            return Response({'error': 'Driver not found'}, status=404)
        
        # Verify face
        face_result = self._verify_face(driver, image_file, org)
        if not face_result['success']:
            return Response(face_result, status=401)
        
        # Create Trip
        now = timezone.now()
        
        # Check if driver already has an incomplete trip today
        existing_trip = Trip.objects.filter(
            driver=driver,
            date=now.date(),
            status__in=['driver_checked_in', 'helper_checked_in', 'helper_skipped', 'checkin_complete']
        ).first()
        
        if existing_trip:
            return Response({
                'success': False,
                'error': f'You already have an active trip for today. Trip ID: {existing_trip.id}',
                'trip_id': str(existing_trip.id)
            }, status=400)
        
        # Save face detection result
        detection = LoginDetectionResult.objects.create(
            organization=org,
            employee=driver,
            face_confidence=face_result['confidence'],
            detections={},
            compliance_passed=True
        )
        # Save image
        from django.core.files.base import ContentFile
        image_file.seek(0)
        detection.frame_image.save(
            f'{employee_id}_{now.strftime("%Y%m%d_%H%M%S")}_driver.jpg',
            ContentFile(image_file.read()),
            save=True
        )
        
        # Create Trip
        trip = Trip.objects.create(
            organization=org,
            driver=driver,
            checkin_time=now,
            checkin_driver_detection=detection,
            status='driver_checked_in'
        )
        
        return Response({
            'success': True,
            'message': f'Driver {driver.full_name} checked in!',
            'trip_id': str(trip.id),
            'next_step': 'helper-checkin',
            'time': now.isoformat()
        })
    
    @action(detail=True, methods=['post'], url_path='helper-checkin')
    def helper_checkin(self, request, pk=None):
        """
        Step 2: Helper checks in with face verification.
        
        POST /trips/{trip_id}/helper-checkin/
        Body: employee_id, password, image (face photo)
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status not in ['driver_checked_in']:
            return Response({
                'error': f'Cannot add helper. Trip status: {trip.status}'
            }, status=400)
        
        employee_id = request.data.get('employee_id', '').strip()
        password = request.data.get('password', '').strip()
        image_file = request.FILES.get('image')
        
        if not employee_id or not image_file:
            return Response({'error': 'employee_id and image required'}, status=400)
        
        try:
            helper = SaaSEmployee.objects.get(
                organization=trip.organization,
                employee_id=employee_id,
                status='active'
            )
        except SaaSEmployee.DoesNotExist:
            return Response({'error': 'Helper not found'}, status=404)
        
        # Verify password if provided
        if password and helper.password and helper.password != password:
            return Response({'error': 'Invalid password'}, status=401)
        
        # Verify face
        face_result = self._verify_face(helper, image_file, trip.organization)
        if not face_result['success']:
            return Response(face_result, status=401)
        
        # Save detection
        now = timezone.now()
        detection = LoginDetectionResult.objects.create(
            organization=trip.organization,
            employee=helper,
            face_confidence=face_result['confidence'],
            detections={},
            compliance_passed=True
        )
        from django.core.files.base import ContentFile
        image_file.seek(0)
        detection.frame_image.save(
            f'{employee_id}_{now.strftime("%Y%m%d_%H%M%S")}_helper.jpg',
            ContentFile(image_file.read()),
            save=True
        )
        
        # Update Trip
        trip.helper = helper
        trip.checkin_helper_detection = detection
        trip.status = 'helper_checked_in'
        trip.save()
        
        return Response({
            'success': True,
            'message': f'Helper {helper.full_name} checked in!',
            'trip_id': str(trip.id),
            'next_step': 'vehicle-checkin'
        })
    
    @action(detail=True, methods=['post'], url_path='skip-helper')
    def skip_helper(self, request, pk=None):
        """
        Step 2 (alternative): Skip helper login.
        
        POST /trips/{trip_id}/skip-helper/
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status != 'driver_checked_in':
            return Response({'error': 'Cannot skip helper at this stage'}, status=400)
        
        trip.helper_skipped = True
        trip.status = 'helper_skipped'
        trip.save()
        
        return Response({
            'success': True,
            'message': 'Helper skipped',
            'trip_id': str(trip.id),
            'next_step': 'vehicle-checkin'
        })
    
    @action(detail=True, methods=['post'], url_path='vehicle-checkin')
    def vehicle_checkin(self, request, pk=None):
        """
        Step 3: Capture vehicle image and run YOLO compliance check.
        Completes the check-in process.
        
        POST /trips/{trip_id}/vehicle-checkin/
        Body: image (vehicle photo)
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status not in ['driver_checked_in', 'helper_checked_in', 'helper_skipped']:
            return Response({'error': 'Invalid trip status for vehicle check-in'}, status=400)
        
        image_file = request.FILES.get('image')
        if not image_file:
            return Response({'error': 'Vehicle image required'}, status=400)
        
        # Run YOLO detection
        yolo_result = self._run_yolo_detection(trip.organization, image_file)
        
        # Check compliance
        compliance_result = check_full_compliance(yolo_result['detections'])
        
        # Save VehicleComplianceRecord
        now = timezone.now()
        
        vehicle_record = VehicleComplianceRecord.objects.create(
            organization=trip.organization,
            yolo_model_id=yolo_result.get('model_id'),
            detections=yolo_result['detections'],
            compliance_passed=compliance_result['passed'],
            compliance_details=compliance_result
        )
        
        # Save image (Annotated if available, else original)
        if yolo_result.get('annotated_image'):
            from django.core.files.base import ContentFile
            vehicle_record.vehicle_image.save(
                f'vehicle_checkin_{now.strftime("%Y%m%d_%H%M%S")}.jpg',
                ContentFile(yolo_result['annotated_image']),
                save=True
            )
        else:
            from django.core.files.base import ContentFile
            image_file.seek(0)
            vehicle_record.vehicle_image.save(
                f'vehicle_checkin_{now.strftime("%Y%m%d_%H%M%S")}.jpg',
                ContentFile(image_file.read()),
                save=True
            )
        
        # Update trip
        trip.checkin_vehicle = vehicle_record
        trip.checkin_compliance_passed = compliance_result['passed']
        trip.status = 'checkin_complete'
        trip.save()
        
        return Response({
            'success': True,
            'trip_id': str(trip.id),
            'compliance_passed': compliance_result['passed'],
            'compliance_summary': compliance_result['summary'],
            'detections': yolo_result['detections'],
            'checks': compliance_result['checks'],
            'message': 'Check-in complete!' if compliance_result['passed'] else 'Check-in complete but compliance failed'
        })

    # ... (driver_checkout, helper_checkout, skip_helper_checkout omitted, assume unchanged) ...

    @action(detail=True, methods=['post'], url_path='driver-checkout')
    def driver_checkout(self, request, pk=None):
        """
        Step 4: Driver checks out with face verification.
        
        POST /trips/{trip_id}/driver-checkout/
        Body: image (face photo)
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status != 'checkin_complete':
            return Response({'error': f'Cannot checkout. Trip status: {trip.status}'}, status=400)
        
        image_file = request.FILES.get('image')
        if not image_file:
            return Response({'error': 'Face image required'}, status=400)
        
        # Verify driver face
        face_result = self._verify_face(trip.driver, image_file, trip.organization)
        if not face_result['success']:
            return Response(face_result, status=401)
        
        # Save detection
        now = timezone.now()
        detection = LoginDetectionResult.objects.create(
            organization=trip.organization,
            employee=trip.driver,
            face_confidence=face_result['confidence'],
            detections={},
            compliance_passed=True
        )
        from django.core.files.base import ContentFile
        image_file.seek(0)
        detection.frame_image.save(
            f'{trip.driver.employee_id}_{now.strftime("%Y%m%d_%H%M%S")}_checkout.jpg',
            ContentFile(image_file.read()),
            save=True
        )
        
        trip.checkout_time = now
        trip.checkout_driver_detection = detection
        trip.status = 'checkout_started'
        trip.save()
        
        next_step = 'helper-checkout' if trip.helper and not trip.helper_skipped else 'vehicle-checkout'
        
        return Response({
            'success': True,
            'message': f'Driver {trip.driver.full_name} checkout verified',
            'trip_id': str(trip.id),
            'next_step': next_step
        })
    
    @action(detail=True, methods=['post'], url_path='helper-checkout')
    def helper_checkout(self, request, pk=None):
        """
        Step 5: Helper checks out with face verification.
        
        POST /trips/{trip_id}/helper-checkout/
        Body: employee_id, password, image
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status != 'checkout_started':
            return Response({'error': 'Invalid trip status'}, status=400)
        
        if not trip.helper:
            return Response({'error': 'No helper on this trip'}, status=400)
        
        employee_id = request.data.get('employee_id', '').strip()
        password = request.data.get('password', '').strip()
        image_file = request.FILES.get('image')
        
        if not image_file:
            return Response({'error': 'Face image required'}, status=400)
        
        # Verify it's the same helper
        if employee_id and employee_id != trip.helper.employee_id:
            return Response({'error': 'Helper ID does not match trip'}, status=400)
        
        # Verify password
        if password and trip.helper.password and trip.helper.password != password:
            return Response({'error': 'Invalid password'}, status=401)
        
        # Verify face
        face_result = self._verify_face(trip.helper, image_file, trip.organization)
        if not face_result['success']:
            return Response(face_result, status=401)
        
        # Save detection
        now = timezone.now()
        detection = LoginDetectionResult.objects.create(
            organization=trip.organization,
            employee=trip.helper,
            face_confidence=face_result['confidence'],
            detections={},
            compliance_passed=True
        )
        from django.core.files.base import ContentFile
        image_file.seek(0)
        detection.frame_image.save(
            f'{trip.helper.employee_id}_{now.strftime("%Y%m%d_%H%M%S")}_helper_out.jpg',
            ContentFile(image_file.read()),
            save=True
        )
        
        trip.checkout_helper_detection = detection
        trip.save()
        
        return Response({
            'success': True,
            'message': f'Helper {trip.helper.full_name} checkout verified',
            'trip_id': str(trip.id),
            'next_step': 'vehicle-checkout'
        })
    
    @action(detail=True, methods=['post'], url_path='skip-helper-checkout')
    def skip_helper_checkout(self, request, pk=None):
        """Skip helper checkout if needed"""
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status != 'checkout_started':
            return Response({'error': 'Invalid trip status'}, status=400)
        
        return Response({
            'success': True,
            'message': 'Helper checkout skipped',
            'trip_id': str(trip.id),
            'next_step': 'vehicle-checkout'
        })
    
    @action(detail=True, methods=['post'], url_path='vehicle-checkout')
    def vehicle_checkout(self, request, pk=None):
        """
        Step 6: Capture vehicle image and complete trip.
        
        POST /trips/{trip_id}/vehicle-checkout/
        Body: image (vehicle photo)
        """
        trip = get_object_or_404(Trip, pk=pk)
        
        if trip.status != 'checkout_started':
            return Response({'error': 'Invalid trip status for vehicle checkout'}, status=400)
        
        image_file = request.FILES.get('image')
        if not image_file:
            return Response({'error': 'Vehicle image required'}, status=400)
        
        # Run YOLO detection
        yolo_result = self._run_yolo_detection(trip.organization, image_file)
        
        # Check compliance
        compliance_result = check_full_compliance(yolo_result['detections'])
        
        # Save VehicleComplianceRecord
        now = timezone.now()
        
        vehicle_record = VehicleComplianceRecord.objects.create(
            organization=trip.organization,
            yolo_model_id=yolo_result.get('model_id'),
            detections=yolo_result['detections'],
            compliance_passed=compliance_result['passed'],
            compliance_details=compliance_result
        )
        
        # Save image (Annotated if available, else original)
        if yolo_result.get('annotated_image'):
            from django.core.files.base import ContentFile
            vehicle_record.vehicle_image.save(
                f'vehicle_checkout_{now.strftime("%Y%m%d_%H%M%S")}.jpg',
                ContentFile(yolo_result['annotated_image']),
                save=True
            )
        else:
            from django.core.files.base import ContentFile
            image_file.seek(0)
            vehicle_record.vehicle_image.save(
                f'vehicle_checkout_{now.strftime("%Y%m%d_%H%M%S")}.jpg',
                ContentFile(image_file.read()),
                save=True
            )
        
        # Complete trip
        trip.checkout_vehicle = vehicle_record
        trip.checkout_compliance_passed = compliance_result['passed']
        trip.status = 'completed'
        trip.calculate_work_duration()
        
        return Response({
            'success': True,
            'trip_id': str(trip.id),
            'compliance_passed': compliance_result['passed'],
            'compliance_summary': compliance_result['summary'],
            'work_duration': str(trip.work_duration) if trip.work_duration else None,
            'message': 'Trip completed successfully!' if compliance_result['passed'] else 'Trip completed but checkout compliance failed'
        })
    
    def _verify_face(self, employee, image_file, org):
        """Verify employee face against stored embeddings."""
        stored_embeddings = employee.face_embeddings or employee.heavy_embeddings
        if not stored_embeddings:
            return {
                'success': False,
                'error': 'No face embeddings found. Please train face model first.'
            }
        
        # Save temp file
        import tempfile
        import os
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_file:
            for chunk in image_file.chunks():
                temp_file.write(chunk)
            temp_path = temp_file.name
        
        try:
            from apps.faces.deepface_service import get_deepface_service
            service = get_deepface_service()
            query_embedding = service.get_embedding(temp_path)
            
            if query_embedding is None:
                return {'success': False, 'error': 'No face detected in image'}
            
            query_embedding = np.array(query_embedding)
            
            # Find best match
            best_distance = float('inf')
            for stored in stored_embeddings:
                stored_arr = np.array(stored)
                dot_product = np.dot(query_embedding, stored_arr)
                norm_product = np.linalg.norm(query_embedding) * np.linalg.norm(stored_arr)
                if norm_product > 0:
                    distance = 1 - (dot_product / norm_product)
                    if distance < best_distance:
                        best_distance = distance
            
            THRESHOLD = 0.4
            if best_distance > THRESHOLD or best_distance == float('inf'):
                return {
                    'success': False,
                    'error': f'Face verification failed (distance: {best_distance:.3f})',
                    'distance': round(best_distance, 3) if best_distance != float('inf') else None
                }
            
            return {
                'success': True,
                'confidence': round(1 - best_distance, 3),
                'distance': round(best_distance, 3)
            }
        except Exception as e:
            return {'success': False, 'error': f'Face verification error: {str(e)}'}
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)
    
    def _run_yolo_detection(self, org, image_file):
        """Run YOLO detection on vehicle image, return detections AND annotated image."""
        # Get active YOLO model for org
        yolo_model = CustomYoloModel.objects.filter(
            organization=org,
            is_active=True
        ).first()
        
        if not yolo_model:
            return {
                'detections': {},
                'model_id': None,
                'annotated_image': None,
                'message': 'No YOLO model configured'
            }
        
        # Save temp file
        import tempfile
        import os
        import cv2
        import numpy as np
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_file:
            for chunk in image_file.chunks():
                temp_file.write(chunk)
            temp_path = temp_file.name
        
        try:
            from ultralytics import YOLO
            model = YOLO(yolo_model.model_file.path)
            results = model(temp_path)
            
            # Count detections by class
            detections = {}
            if results and len(results) > 0:
                for r in results:
                    for box in r.boxes:
                        class_id = int(box.cls[0])
                        class_name = r.names[class_id]
                        detections[class_name] = detections.get(class_name, 0) + 1
            
            # Generate Annotated Image (with boxes)
            annotated_image = None
            if results and len(results) > 0:
                # Plot returns BGR numpy array
                im_array = results[0].plot()
                # Convert BGR to RGB (actually cv2.imencode expects BGR, but Django logic might differ)
                # Wait, cv2 uses BGR. imencode expects BGR. 
                # So we can just encode it.
                
                success, encoded_img = cv2.imencode('.jpg', im_array)
                if success:
                    annotated_image = encoded_img.tobytes()
            
            return {
                'detections': detections,
                'model_id': str(yolo_model.id),
                'model_name': yolo_model.name,
                'annotated_image': annotated_image
            }
        except Exception as e:
            print(f"YOLO Error: {e}")
            return {
                'detections': {},
                'model_id': str(yolo_model.id) if yolo_model else None,
                'annotated_image': None,
                'error': str(e)
            }
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)
