"""ML Models app - Model versioning and training."""
default_app_config = 'apps.ml_models.apps.MlModelsConfig'
