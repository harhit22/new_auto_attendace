"""Analytics app - Dashboard and reporting."""
default_app_config = 'apps.analytics.apps.AnalyticsConfig'
