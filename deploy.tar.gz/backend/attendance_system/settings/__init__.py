"""
Django settings package.
Import the appropriate settings based on environment.
"""
