"""
One-time script to migrate existing trained employees to the new dual model fields.
Run: python manage.py shell < fix_trained_status.py
"""
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'attendance_system.settings')
django.setup()

from core.models import SaaSEmployee as Employee

# Find all employees with face_enrolled=True
trained_employees = Employee.objects.filter(face_enrolled=True)

print(f"Found {trained_employees.count()} trained employees to migrate...")

for emp in trained_employees:
    updated = False
    mode = (emp.training_mode or '').lower()
    
    # Check if it was light training
    if 'light' in mode or 'quick' in mode:
        if not emp.light_trained:
            emp.light_trained = True
            emp.light_embeddings = emp.face_embeddings
            emp.light_trained_at = emp.last_trained_at
            updated = True
            print(f"  ✅ {emp.full_name}: Set as Light trained")
    
    # Check if it was heavy training  
    elif 'heavy' in mode or 'deep' in mode:
        if not emp.heavy_trained:
            emp.heavy_trained = True
            emp.heavy_embeddings = emp.face_embeddings
            emp.heavy_trained_at = emp.last_trained_at
            updated = True
            print(f"  ✅ {emp.full_name}: Set as Heavy trained")
    
    # If no mode specified but face_enrolled, assume light
    elif not emp.light_trained and not emp.heavy_trained:
        emp.light_trained = True
        emp.light_embeddings = emp.face_embeddings
        emp.light_trained_at = emp.last_trained_at
        emp.training_mode = 'light'
        updated = True
        print(f"  ✅ {emp.full_name}: Set as Light trained (assumed)")
    
    if updated:
        emp.save()

print("\n✅ Migration complete!")
