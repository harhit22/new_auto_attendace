/**
 * Vehicle Capture Page
 * Part of trip check-in flow: Driver -> Helper -> Vehicle capture with YOLO compliance
 */
import React, { useState, useRef, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Webcam from 'react-webcam';

const API_BASE = '/api/v1/attendance';

const VehicleCapturePage = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const tripId = searchParams.get('trip');
    const action = searchParams.get('action') || 'checkin'; // checkin or checkout

    const webcamRef = useRef(null);
    const [capturedImage, setCapturedImage] = useState(null);
    const [status, setStatus] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [complianceResult, setComplianceResult] = useState(null);

    const driver = JSON.parse(sessionStorage.getItem('employee') || '{}');

    const capture = useCallback(() => {
        if (webcamRef.current) {
            const screenshot = webcamRef.current.getScreenshot();
            setCapturedImage(screenshot);
            setStatus('');
            setComplianceResult(null);
        }
    }, [webcamRef]);

    const retake = () => {
        setCapturedImage(null);
        setStatus('');
        setComplianceResult(null);
    };

    const submitForCompliance = async () => {
        if (!capturedImage) {
            setStatus('❌ Please capture an image first');
            return;
        }

        setIsLoading(true);
        setStatus('🔍 Running YOLO compliance check...');

        try {
            const formData = new FormData();
            const blob = await (await fetch(capturedImage)).blob();
            formData.append('image', blob, 'vehicle.jpg');

            const endpoint = action === 'checkout'
                ? `${API_BASE}/trips/${tripId}/vehicle-checkout/`
                : `${API_BASE}/trips/${tripId}/vehicle-checkin/`;

            const res = await fetch(endpoint, {
                method: 'POST',
                body: formData
            });

            const data = await res.json();

            if (res.ok) {
                setComplianceResult(data);
                if (data.compliance_passed) {
                    setStatus('🎉 Compliance Passed!');
                } else {
                    setStatus('⚠️ Compliance Failed - Issues detected');
                }
            } else {
                setStatus(`❌ ${data.error || 'Failed to process'}`);
            }
        } catch (e) {
            console.error(e);
            setStatus('❌ Network error');
        }

        setIsLoading(false);
    };

    const goToDashboard = () => {
        navigate('/employee/dashboard');
    };

    const renderComplianceDetails = () => {
        if (!complianceResult) return null;

        const { checks, detections } = complianceResult;

        return (
            <div style={{ marginTop: '20px' }}>
                {/* Summary */}
                <div style={{
                    padding: '20px',
                    background: complianceResult.compliance_passed
                        ? 'rgba(34, 197, 94, 0.1)'
                        : 'rgba(239, 68, 68, 0.1)',
                    borderRadius: '12px',
                    marginBottom: '16px',
                    textAlign: 'center'
                }}>
                    <div style={{ fontSize: '3rem', marginBottom: '8px' }}>
                        {complianceResult.compliance_passed ? '✅' : '❌'}
                    </div>
                    <div style={{
                        fontSize: '1.2rem',
                        fontWeight: '700',
                        color: complianceResult.compliance_passed ? 'var(--success)' : 'var(--error)'
                    }}>
                        {complianceResult.compliance_passed ? 'COMPLIANCE PASSED' : 'COMPLIANCE FAILED'}
                    </div>
                    <div style={{ marginTop: '8px', color: 'var(--text-muted)' }}>
                        {complianceResult.compliance_summary}
                    </div>
                </div>

                {/* Detections */}
                {detections && Object.keys(detections).length > 0 && (
                    <div style={{ marginBottom: '16px' }}>
                        <h4 style={{ marginBottom: '12px' }}>🔍 Detected Items</h4>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '10px' }}>
                            {Object.entries(detections).map(([key, count]) => (
                                <div key={key} style={{
                                    padding: '12px',
                                    background: 'var(--bg-soft)',
                                    borderRadius: '8px',
                                    textAlign: 'center'
                                }}>
                                    <div style={{ fontSize: '1.2rem', fontWeight: '600' }}>{count}</div>
                                    <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>
                                        {key.replace(/_/g, ' ')}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Compliance Checks */}
                {checks && (
                    <div>
                        <h4 style={{ marginBottom: '12px' }}>📋 Compliance Checks</h4>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            {checks.required && (
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                    padding: '12px', background: 'var(--bg-soft)', borderRadius: '8px'
                                }}>
                                    <span>Required Items (Hooter, Logo, Nagar Nigam)</span>
                                    <span style={{
                                        color: checks.required.passed ? 'var(--success)' : 'var(--error)',
                                        fontWeight: '600'
                                    }}>
                                        {checks.required.passed ? '✓ Pass' : `✗ Missing: ${checks.required.missing?.join(', ')}`}
                                    </span>
                                </div>
                            )}
                            {checks.number_plate && (
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                    padding: '12px', background: 'var(--bg-soft)', borderRadius: '8px'
                                }}>
                                    <span>Number Plate</span>
                                    <span style={{
                                        color: checks.number_plate.passed ? 'var(--success)' : 'var(--error)',
                                        fontWeight: '600'
                                    }}>
                                        {checks.number_plate.passed ? '✓ Pass' : '✗ Fail'}
                                    </span>
                                </div>
                            )}
                            {checks.uniform && (
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                    padding: '12px', background: 'var(--bg-soft)', borderRadius: '8px'
                                }}>
                                    <span>Uniform Compliance</span>
                                    <span style={{
                                        color: checks.uniform.passed ? 'var(--success)' : 'var(--error)',
                                        fontWeight: '600'
                                    }}>
                                        {checks.uniform.passed ? '✓ Pass' : '✗ Fail'}
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Done Button */}
                <button
                    onClick={goToDashboard}
                    className="btn btn-primary btn-lg"
                    style={{ width: '100%', marginTop: '20px' }}
                >
                    ✅ Done - Go to Dashboard
                </button>
            </div>
        );
    };

    return (
        <div style={{ minHeight: '100vh', background: 'var(--bg-muted)' }}>
            {/* Header */}
            <div style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
                padding: '30px 20px',
                color: 'white'
            }}>
                <div style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
                    <h1 style={{ fontSize: '1.5rem', marginBottom: '8px' }}>
                        🚗 Vehicle Compliance Check
                    </h1>
                    <p style={{ opacity: 0.9 }}>
                        Step 3 of 3 • {action === 'checkout' ? 'Checkout' : 'Check-in'} • Driver: {driver.name || 'Unknown'}
                    </p>
                </div>
            </div>

            {/* Content */}
            <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
                <div className="card" style={{ padding: '24px' }}>

                    {!complianceResult ? (
                        <>
                            <h3 style={{ marginBottom: '16px', textAlign: 'center' }}>
                                Capture Vehicle Image
                            </h3>
                            <p style={{ textAlign: 'center', marginBottom: '16px', color: 'var(--text-muted)' }}>
                                Position the camera to capture the vehicle clearly. Include hooter, number plate, and uniform in frame.
                            </p>

                            {/* Camera / Preview */}
                            <div style={{ borderRadius: '16px', overflow: 'hidden', marginBottom: '16px', position: 'relative', background: '#000' }}>
                                {!capturedImage ? (
                                    <Webcam
                                        ref={webcamRef}
                                        audio={false}
                                        screenshotFormat="image/jpeg"
                                        screenshotQuality={0.9}
                                        videoConstraints={{
                                            width: 640,
                                            height: 480,
                                            facingMode: { ideal: 'environment' } // Prefer rear camera
                                        }}
                                        style={{ width: '100%', display: 'block' }}
                                    />
                                ) : (
                                    <img src={capturedImage} alt="Captured" style={{ width: '100%', display: 'block' }} />
                                )}
                            </div>

                            {/* Status */}
                            {status && (
                                <div style={{
                                    padding: '12px', textAlign: 'center', marginBottom: '16px',
                                    background: status.includes('🎉') ? 'rgba(34, 197, 94, 0.1)' :
                                        status.includes('❌') || status.includes('⚠️') ? 'rgba(239, 68, 68, 0.1)' :
                                            'rgba(59, 130, 246, 0.1)',
                                    borderRadius: '10px'
                                }}>
                                    {status}
                                </div>
                            )}

                            {/* Buttons */}
                            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                                {!capturedImage ? (
                                    <button
                                        onClick={capture}
                                        className="btn btn-primary btn-lg"
                                        style={{ flex: 1 }}
                                    >
                                        📷 Capture Photo
                                    </button>
                                ) : (
                                    <>
                                        <button
                                            onClick={submitForCompliance}
                                            disabled={isLoading}
                                            className="btn btn-primary btn-lg"
                                            style={{ flex: 1 }}
                                        >
                                            {isLoading ? '⏳ Checking...' : '✅ Submit for Compliance'}
                                        </button>
                                        <button
                                            onClick={retake}
                                            disabled={isLoading}
                                            className="btn btn-outline"
                                        >
                                            🔄 Retake
                                        </button>
                                    </>
                                )}
                            </div>
                        </>
                    ) : (
                        renderComplianceDetails()
                    )}
                </div>
            </div>
        </div>
    );
};

export default VehicleCapturePage;
