/**
 * Helper Login Page
 * Part of the trip check-in flow: Driver checked in -> Helper login -> Vehicle capture
 */
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';

const API_BASE = '/api/v1/attendance';

const HelperLoginPage = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const tripId = searchParams.get('trip');

    const webcamRef = useRef(null);
    const [employeeId, setEmployeeId] = useState('');
    const [password, setPassword] = useState('');
    const [step, setStep] = useState('login'); // login | face
    const [status, setStatus] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [modelsLoaded, setModelsLoaded] = useState(false);
    const [employee, setEmployee] = useState(null);

    // Get driver info from session
    const driver = JSON.parse(sessionStorage.getItem('employee') || '{}');

    useEffect(() => {
        if (!tripId) {
            navigate('/employee/dashboard');
        }
    }, [tripId, navigate]);

    // Load face-api models when showing webcam
    useEffect(() => {
        const loadModels = async () => {
            try {
                const MODEL_URL = '/models';
                await Promise.all([
                    faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
                    faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
                    faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
                ]);
                setModelsLoaded(true);
            } catch (e) {
                console.error('Failed to load face models:', e);
            }
        };
        if (step === 'face') loadModels();
    }, [step]);

    const handleSkip = async () => {
        setIsLoading(true);
        setStatus('Skipping helper...');

        try {
            const res = await fetch(`${API_BASE}/trips/${tripId}/skip-helper/`, {
                method: 'POST'
            });
            const data = await res.json();

            if (res.ok && data.success) {
                navigate(`/employee/vehicle-capture?trip=${tripId}`);
            } else {
                setStatus(`❌ ${data.error || 'Failed to skip'}`);
            }
        } catch (e) {
            setStatus('❌ Network error');
        }
        setIsLoading(false);
    };

    const handleLoginSubmit = async (e) => {
        e.preventDefault();
        if (!employeeId) {
            setStatus('Please enter Helper ID');
            return;
        }

        // Store helper info and go to face verification
        setEmployee({ employee_id: employeeId, password });
        setStep('face');
        setStatus('');
    };

    const verifyFace = async () => {
        if (!webcamRef.current || !modelsLoaded || isLoading) return;

        setIsLoading(true);
        setStatus('🔍 Detecting face...');

        try {
            const screenshot = webcamRef.current.getScreenshot();
            if (!screenshot) {
                setStatus('❌ Could not capture image');
                setIsLoading(false);
                return;
            }

            // Detect face
            const imgElement = document.createElement('img');
            imgElement.src = screenshot;
            await new Promise(r => imgElement.onload = r);

            const detection = await faceapi
                .detectSingleFace(imgElement, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
                .withFaceLandmarks()
                .withFaceDescriptor();

            if (!detection) {
                setStatus('⚠️ No face detected. Please look at the camera.');
                setIsLoading(false);
                return;
            }

            setStatus('✅ Face detected! Verifying...');

            // Send to backend
            const formData = new FormData();
            const blob = await (await fetch(screenshot)).blob();
            formData.append('image', blob, 'face.jpg');
            formData.append('employee_id', employee.employee_id);
            formData.append('password', employee.password || '');

            const res = await fetch(`${API_BASE}/trips/${tripId}/helper-checkin/`, {
                method: 'POST',
                body: formData
            });

            const data = await res.json();

            if (res.ok && data.success) {
                setStatus(`🎉 ${data.message}`);
                setTimeout(() => {
                    navigate(`/employee/vehicle-capture?trip=${tripId}`);
                }, 1500);
            } else {
                setStatus(`❌ ${data.error || 'Verification failed'}`);
            }
        } catch (e) {
            console.error(e);
            setStatus('❌ Error during verification');
        }

        setIsLoading(false);
    };

    return (
        <div style={{ minHeight: '100vh', background: 'var(--bg-muted)' }}>
            {/* Header */}
            <div style={{
                background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                padding: '30px 20px',
                color: 'white'
            }}>
                <div style={{ maxWidth: '500px', margin: '0 auto', textAlign: 'center' }}>
                    <h1 style={{ fontSize: '1.5rem', marginBottom: '8px' }}>
                        👷 Helper Check-In
                    </h1>
                    <p style={{ opacity: 0.9 }}>
                        Step 2 of 3 • Driver: {driver.name || 'Unknown'}
                    </p>
                </div>
            </div>

            {/* Content */}
            <div style={{ maxWidth: '500px', margin: '0 auto', padding: '20px' }}>
                <div className="card" style={{ padding: '24px' }}>

                    {step === 'login' ? (
                        <>
                            <h3 style={{ marginBottom: '20px', textAlign: 'center' }}>
                                Enter Helper Details
                            </h3>

                            <form onSubmit={handleLoginSubmit}>
                                <div style={{ marginBottom: '16px' }}>
                                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500' }}>
                                        Helper Employee ID
                                    </label>
                                    <input
                                        type="text"
                                        value={employeeId}
                                        onChange={e => setEmployeeId(e.target.value)}
                                        placeholder="Enter helper's employee ID"
                                        style={{
                                            width: '100%', padding: '14px', fontSize: '1rem',
                                            border: '2px solid var(--bg-soft)', borderRadius: '10px'
                                        }}
                                    />
                                </div>

                                <div style={{ marginBottom: '20px' }}>
                                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500' }}>
                                        Password (Optional)
                                    </label>
                                    <input
                                        type="password"
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        placeholder="Enter password if set"
                                        style={{
                                            width: '100%', padding: '14px', fontSize: '1rem',
                                            border: '2px solid var(--bg-soft)', borderRadius: '10px'
                                        }}
                                    />
                                </div>

                                {status && (
                                    <div style={{
                                        padding: '12px', marginBottom: '16px', textAlign: 'center',
                                        background: 'rgba(239, 68, 68, 0.1)', borderRadius: '10px',
                                        color: 'var(--error)'
                                    }}>
                                        {status}
                                    </div>
                                )}

                                <button
                                    type="submit"
                                    className="btn btn-primary btn-lg"
                                    style={{ width: '100%', marginBottom: '12px' }}
                                >
                                    Continue to Face Verification →
                                </button>

                                <button
                                    type="button"
                                    onClick={handleSkip}
                                    disabled={isLoading}
                                    className="btn btn-outline"
                                    style={{ width: '100%' }}
                                >
                                    {isLoading ? 'Skipping...' : 'Skip Helper (Proceed Alone)'}
                                </button>
                            </form>
                        </>
                    ) : (
                        <>
                            <h3 style={{ marginBottom: '20px', textAlign: 'center' }}>
                                Verify Helper Face
                            </h3>
                            <p style={{ textAlign: 'center', marginBottom: '16px', color: 'var(--text-muted)' }}>
                                Helper ID: <strong>{employee?.employee_id}</strong>
                            </p>

                            {/* Webcam */}
                            <div style={{ borderRadius: '16px', overflow: 'hidden', marginBottom: '16px', position: 'relative' }}>
                                <Webcam
                                    ref={webcamRef}
                                    audio={false}
                                    screenshotFormat="image/jpeg"
                                    screenshotQuality={0.8}
                                    videoConstraints={{ width: 480, height: 360, facingMode: 'user' }}
                                    style={{ width: '100%', display: 'block' }}
                                    mirrored={true}
                                />
                                {/* Face oval overlay */}
                                <div style={{
                                    position: 'absolute', top: '50%', left: '50%',
                                    transform: 'translate(-50%, -50%)',
                                    width: '150px', height: '180px',
                                    border: '3px dashed rgba(255,255,255,0.5)',
                                    borderRadius: '50%'
                                }}></div>
                            </div>

                            {/* Status */}
                            {status && (
                                <div style={{
                                    padding: '12px', textAlign: 'center', marginBottom: '16px',
                                    background: status.includes('🎉') ? 'rgba(34, 197, 94, 0.1)' :
                                        status.includes('❌') || status.includes('⚠️') ? 'rgba(239, 68, 68, 0.1)' :
                                            'rgba(59, 130, 246, 0.1)',
                                    borderRadius: '10px'
                                }}>
                                    {status}
                                </div>
                            )}

                            {/* Buttons */}
                            <div style={{ display: 'flex', gap: '12px' }}>
                                <button
                                    onClick={verifyFace}
                                    disabled={!modelsLoaded || isLoading}
                                    className="btn btn-primary btn-lg"
                                    style={{ flex: 1 }}
                                >
                                    {isLoading ? '⏳ Verifying...' : modelsLoaded ? '✅ Verify Face' : '⏳ Loading...'}
                                </button>
                                <button
                                    onClick={() => { setStep('login'); setStatus(''); }}
                                    className="btn btn-outline"
                                >
                                    Back
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default HelperLoginPage;
