/**
 * Admin Attendance Page - Trip View
 * Shows trips with driver, helper, and vehicle compliance images
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const API_BASE = '/api/v1/attendance';
const MEDIA_BASE = '';

const AdminAttendancePage = () => {
    const navigate = useNavigate();
    const { attendanceOrg, isAttendanceLoggedIn } = useAuth();
    const [trips, setTrips] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (isAttendanceLoggedIn && attendanceOrg) {
            loadTrips(attendanceOrg.id);
        }
        // No need to redirect here logic is handled by ProtectedRoute
    }, [isAttendanceLoggedIn, attendanceOrg]);

    const loadTrips = async (orgId) => {
        setLoading(true);
        try {
            const res = await fetch(`${API_BASE}/trips/?organization_id=${orgId}`);
            const data = await res.json();
            if (res.ok) {
                setTrips(data.trips || []);
            }
        } catch (e) {
            console.error('Failed to load trips:', e);
        }
        setLoading(false);
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'completed': return { bg: 'rgba(34, 197, 94, 0.1)', color: '#22c55e' };
            case 'checkin_complete': return { bg: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6' };
            case 'driver_checked_in':
            case 'helper_checked_in':
            case 'helper_skipped':
                return { bg: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b' };
            default: return { bg: 'rgba(156, 163, 175, 0.1)', color: '#9ca3af' };
        }
    };

    const formatTime = (isoString) => {
        if (!isoString) return '-';
        return new Date(isoString).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        return new Date(dateStr).toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });
    };

    if (loading) {
        return (
            <div style={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'var(--bg-muted)'
            }}>
                <div className="spinner"></div>
            </div>
        );
    }

    return (
        <div style={{ minHeight: '100vh', background: 'var(--bg-muted)' }}>
            {/* Header */}
            <div style={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                padding: '30px 20px',
                color: 'white'
            }}>
                <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <h1 style={{ fontSize: '1.8rem', marginBottom: '4px' }}>
                                🚗 Trip Attendance
                            </h1>
                            <p style={{ opacity: 0.9 }}>
                                {attendanceOrg?.name} • Driver + Helper + Vehicle Compliance
                            </p>
                        </div>
                        <button
                            onClick={() => navigate('/attendance/admin')}
                            style={{
                                background: 'rgba(255,255,255,0.2)',
                                border: 'none',
                                color: 'white',
                                padding: '10px 20px',
                                borderRadius: '8px',
                                cursor: 'pointer'
                            }}
                        >
                            ← Back to Dashboard
                        </button>
                    </div>
                </div>
            </div>

            {/* Content */}
            <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
                {trips.length === 0 ? (
                    <div className="card" style={{ padding: '60px', textAlign: 'center' }}>
                        <div style={{ fontSize: '4rem', marginBottom: '16px' }}>🚗</div>
                        <h3 style={{ marginBottom: '8px' }}>No Trips Yet</h3>
                        <p style={{ color: 'var(--text-muted)' }}>
                            Trips will appear here when employees check in using the trip workflow.
                        </p>
                    </div>
                ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                        {trips.map((trip) => (
                            <TripCard key={trip.id} trip={trip} formatTime={formatTime} formatDate={formatDate} getStatusColor={getStatusColor} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

const TripCard = ({ trip, formatTime, formatDate, getStatusColor }) => {
    const [expanded, setExpanded] = useState(false);
    const statusStyle = getStatusColor(trip.status);

    return (
        <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
            {/* Header */}
            <div
                onClick={() => setExpanded(!expanded)}
                style={{
                    padding: '20px',
                    cursor: 'pointer',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    borderBottom: expanded ? '1px solid var(--bg-soft)' : 'none'
                }}
            >
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <div style={{
                        width: '50px', height: '50px',
                        borderRadius: '12px',
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: 'white', fontSize: '1.5rem'
                    }}>
                        🚗
                    </div>
                    <div>
                        <div style={{ fontWeight: '600', fontSize: '1.1rem' }}>
                            {trip.driver?.name || 'Unknown Driver'}
                            {trip.helper && !trip.helper_skipped && (
                                <span style={{ color: 'var(--text-muted)', fontWeight: '400' }}>
                                    {' '}+ {trip.helper.name}
                                </span>
                            )}
                            {trip.helper_skipped && (
                                <span style={{ color: 'var(--text-muted)', fontWeight: '400', fontStyle: 'italic' }}>
                                    {' '}(No Helper)
                                </span>
                            )}
                        </div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                            {formatDate(trip.date)} • In: {formatTime(trip.checkin_time)} • Out: {formatTime(trip.checkout_time)}
                        </div>
                    </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    {/* Compliance badges */}
                    {trip.checkin_compliance_passed !== undefined && (
                        <div style={{
                            padding: '6px 12px',
                            borderRadius: '50px',
                            fontSize: '0.8rem',
                            fontWeight: '600',
                            background: trip.checkin_compliance_passed ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)',
                            color: trip.checkin_compliance_passed ? '#22c55e' : '#ef4444'
                        }}>
                            {trip.checkin_compliance_passed ? '✅ In' : '❌ In'}
                        </div>
                    )}
                    {trip.checkout_compliance_passed !== undefined && trip.status === 'completed' && (
                        <div style={{
                            padding: '6px 12px',
                            borderRadius: '50px',
                            fontSize: '0.8rem',
                            fontWeight: '600',
                            background: trip.checkout_compliance_passed ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)',
                            color: trip.checkout_compliance_passed ? '#22c55e' : '#ef4444'
                        }}>
                            {trip.checkout_compliance_passed ? '✅ Out' : '❌ Out'}
                        </div>
                    )}

                    {/* Status */}
                    <div style={{
                        padding: '6px 14px',
                        borderRadius: '50px',
                        fontSize: '0.85rem',
                        fontWeight: '500',
                        background: statusStyle.bg,
                        color: statusStyle.color,
                        textTransform: 'capitalize'
                    }}>
                        {trip.status.replace(/_/g, ' ')}
                    </div>

                    {/* Duration */}
                    {trip.work_duration && (
                        <div style={{ fontWeight: '600', color: 'var(--primary)' }}>
                            ⏱️ {trip.work_duration}
                        </div>
                    )}

                    <span style={{ fontSize: '1.2rem' }}>{expanded ? '▲' : '▼'}</span>
                </div>
            </div>

            {/* Expanded Content */}
            {expanded && (
                <div style={{ padding: '20px' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>

                        {/* CHECK-IN Section */}
                        <div style={{ background: 'var(--bg-soft)', borderRadius: '12px', padding: '16px' }}>
                            <h4 style={{ marginBottom: '16px', color: '#22c55e' }}>📥 Check-In</h4>

                            {/* Driver */}
                            <div style={{ marginBottom: '16px' }}>
                                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                    🚗 Driver: {trip.driver?.name}
                                </div>
                                <TripImage
                                    src={trip.checkin_driver_image}
                                    label="Driver Face"
                                    time={formatTime(trip.checkin_time)}
                                />
                            </div>

                            {/* Helper */}
                            {!trip.helper_skipped && trip.helper && (
                                <div style={{ marginBottom: '16px' }}>
                                    <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                        👷 Helper: {trip.helper?.name}
                                    </div>
                                    <TripImage
                                        src={trip.checkin_helper_image}
                                        label="Helper Face"
                                    />
                                </div>
                            )}

                            {/* Vehicle */}
                            <div>
                                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                    🚛 Vehicle Capture
                                </div>
                                <TripImage
                                    src={trip.checkin_vehicle_image}
                                    label="Vehicle"
                                    isVehicle
                                />
                                {trip.checkin_vehicle_detections && Object.keys(trip.checkin_vehicle_detections).length > 0 && (
                                    <div style={{ marginTop: '8px', display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                        {Object.entries(trip.checkin_vehicle_detections).map(([key, count]) => (
                                            <span key={key} style={{
                                                padding: '4px 8px',
                                                background: 'rgba(59,130,246,0.1)',
                                                color: '#3b82f6',
                                                borderRadius: '6px',
                                                fontSize: '0.75rem'
                                            }}>
                                                {key}: {count}
                                            </span>
                                        ))}
                                    </div>
                                )}
                                {trip.checkin_compliance_passed !== undefined && (
                                    <div style={{
                                        marginTop: '8px',
                                        padding: '8px 12px',
                                        borderRadius: '8px',
                                        fontSize: '0.85rem',
                                        background: trip.checkin_compliance_passed ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)',
                                        color: trip.checkin_compliance_passed ? '#22c55e' : '#ef4444'
                                    }}>
                                        {trip.checkin_compliance_passed ? '✅ Compliance Passed' : '❌ Compliance Failed'}
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* CHECK-OUT Section */}
                        <div style={{
                            background: trip.status === 'completed' ? 'var(--bg-soft)' : 'rgba(156,163,175,0.05)',
                            borderRadius: '12px',
                            padding: '16px',
                            opacity: trip.status === 'completed' ? 1 : 0.5
                        }}>
                            <h4 style={{ marginBottom: '16px', color: '#f59e0b' }}>📤 Check-Out</h4>

                            {trip.status !== 'completed' ? (
                                <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-muted)' }}>
                                    Trip not yet completed
                                </div>
                            ) : (
                                <>
                                    {/* Driver */}
                                    <div style={{ marginBottom: '16px' }}>
                                        <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                            🚗 Driver: {trip.driver?.name}
                                        </div>
                                        <TripImage
                                            src={trip.checkout_driver_image}
                                            label="Driver Face"
                                            time={formatTime(trip.checkout_time)}
                                        />
                                    </div>

                                    {/* Helper */}
                                    {!trip.helper_skipped && trip.helper && (
                                        <div style={{ marginBottom: '16px' }}>
                                            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                                👷 Helper: {trip.helper?.name}
                                            </div>
                                            <TripImage
                                                src={trip.checkout_helper_image}
                                                label="Helper Face"
                                            />
                                        </div>
                                    )}

                                    {/* Vehicle */}
                                    <div>
                                        <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                                            🚛 Vehicle Capture
                                        </div>
                                        <TripImage
                                            src={trip.checkout_vehicle_image}
                                            label="Vehicle"
                                            isVehicle
                                        />
                                        {trip.checkout_vehicle_detections && Object.keys(trip.checkout_vehicle_detections).length > 0 && (
                                            <div style={{ marginTop: '8px', display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                                {Object.entries(trip.checkout_vehicle_detections).map(([key, count]) => (
                                                    <span key={key} style={{
                                                        padding: '4px 8px',
                                                        background: 'rgba(59,130,246,0.1)',
                                                        color: '#3b82f6',
                                                        borderRadius: '6px',
                                                        fontSize: '0.75rem'
                                                    }}>
                                                        {key}: {count}
                                                    </span>
                                                ))}
                                            </div>
                                        )}
                                        {trip.checkout_compliance_passed !== undefined && (
                                            <div style={{
                                                marginTop: '8px',
                                                padding: '8px 12px',
                                                borderRadius: '8px',
                                                fontSize: '0.85rem',
                                                background: trip.checkout_compliance_passed ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)',
                                                color: trip.checkout_compliance_passed ? '#22c55e' : '#ef4444'
                                            }}>
                                                {trip.checkout_compliance_passed ? '✅ Compliance Passed' : '❌ Compliance Failed'}
                                            </div>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const TripImage = ({ src, label, time, isVehicle }) => {
    if (src) {
        return (
            <div style={{ position: 'relative' }}>
                <img
                    src={`${MEDIA_BASE}${src}`}
                    alt={label}
                    style={{
                        width: '100%',
                        height: isVehicle ? '140px' : '120px',
                        objectFit: 'cover',
                        borderRadius: '10px'
                    }}
                />
                {time && (
                    <div style={{
                        position: 'absolute',
                        bottom: '8px',
                        right: '8px',
                        background: 'rgba(0,0,0,0.6)',
                        color: 'white',
                        padding: '4px 8px',
                        borderRadius: '6px',
                        fontSize: '0.75rem'
                    }}>
                        {time}
                    </div>
                )}
            </div>
        );
    }

    return (
        <div style={{
            width: '100%',
            height: isVehicle ? '120px' : '100px',
            background: 'var(--bg-muted)',
            borderRadius: '10px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-muted)',
            fontSize: '0.85rem',
            border: '2px dashed var(--bg-soft)'
        }}>
            <span style={{ fontSize: '1.5rem', marginBottom: '4px' }}>
                {isVehicle ? '🚛' : '👤'}
            </span>
            <span>{label}</span>
            {time && <span style={{ fontSize: '0.75rem' }}>{time}</span>}
        </div>
    );
};

export default AdminAttendancePage;
