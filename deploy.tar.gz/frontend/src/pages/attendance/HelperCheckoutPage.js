/**
 * Helper Checkout Page
 * Step 5 of Trip Workflow: Helper Face Verification for Checkout
 */
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';

const API_BASE = 'http://localhost:8000/api/v1/attendance';

const HelperCheckoutPage = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const tripId = searchParams.get('trip');

    const webcamRef = useRef(null);
    const [status, setStatus] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [modelsLoaded, setModelsLoaded] = useState(false);

    // Optional password if face fails or as alternative
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);

    useEffect(() => {
        if (!tripId) {
            navigate('/employee/dashboard');
        }
        loadModels();
    }, [tripId, navigate]);

    const loadModels = async () => {
        try {
            await Promise.all([
                faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
                faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
                faceapi.nets.faceRecognitionNet.loadFromUri('/models')
            ]);
            setModelsLoaded(true);
        } catch (e) {
            console.error(e);
            setStatus('Failed to load recognition models');
        }
    };

    const handleSkip = async () => {
        // This endpoint might strip the helper or just log a skip
        setIsLoading(true);
        try {
            const res = await fetch(`${API_BASE}/trips/${tripId}/skip-helper-checkout/`, {
                method: 'POST'
            });
            const data = await res.json();
            if (res.ok && data.success) {
                navigate(`/employee/vehicle-capture?trip=${tripId}&action=checkout`);
            } else {
                setStatus(`❌ ${data.error || 'Failed to skip'}`);
            }
        } catch (e) {
            setStatus('❌ Network error');
        }
        setIsLoading(false);
    };

    const verifyFace = async () => {
        if (!webcamRef.current || !modelsLoaded || isLoading) return;

        setIsLoading(true);
        setStatus('🔍 Detecting face...');

        try {
            const screenshot = webcamRef.current.getScreenshot();
            if (!screenshot) {
                setStatus('❌ Capture failed');
                setIsLoading(false);
                return;
            }

            // Client-side detection
            const imgEl = document.createElement('img');
            imgEl.src = screenshot;
            await new Promise(r => imgEl.onload = r);

            const detection = await faceapi.detectSingleFace(imgEl, new faceapi.TinyFaceDetectorOptions());
            if (!detection) {
                setStatus('⚠️ No face detected');
                setIsLoading(false);
                return;
            }

            setStatus('📤 Verifying with server...');
            const formData = new FormData();
            const blob = await (await fetch(screenshot)).blob();
            formData.append('image', blob, 'helper_face.jpg');
            // If we had the employee ID we could send it, but backend knows from trip
            if (password) formData.append('password', password);

            const res = await fetch(`${API_BASE}/trips/${tripId}/helper-checkout/`, {
                method: 'POST',
                body: formData
            });

            const data = await res.json();

            if (res.ok && data.success) {
                setStatus('✅ Helper Verified!');
                setTimeout(() => {
                    navigate(`/employee/vehicle-capture?trip=${tripId}&action=checkout`);
                }, 1500);
            } else {
                setStatus(`❌ ${data.error || 'Verification Failed'}`);
            }

        } catch (e) {
            console.error(e);
            setStatus('❌ System Error');
        }
        setIsLoading(false);
    };

    return (
        <div style={{ minHeight: '100vh', background: 'var(--bg-muted)', padding: '20px' }}>
            <div className="card" style={{ maxWidth: '500px', margin: '40px auto', padding: '30px', textAlign: 'center' }}>
                <h2 style={{ marginBottom: '10px', color: '#f59e0b' }}>👷 Helper Checkout</h2>
                <p style={{ marginBottom: '20px', color: 'var(--text-muted)' }}>
                    Please verify the helper's presence
                </p>

                <div style={{ marginBottom: '20px', borderRadius: '16px', overflow: 'hidden', position: 'relative' }}>
                    {modelsLoaded ? (
                        <Webcam
                            ref={webcamRef}
                            audio={false}
                            screenshotFormat="image/jpeg"
                            videoConstraints={{ facingMode: 'user' }}
                            style={{ width: '100%', display: 'block' }}
                            mirrored={true}
                        />
                    ) : (
                        <div style={{ height: '300px', background: '#000', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            Loading Camera...
                        </div>
                    )}
                </div>

                <div style={{
                    padding: '12px',
                    marginBottom: '20px',
                    background: status.includes('✅') ? 'rgba(34,197,94,0.1)' : 'rgba(59,130,246,0.1)',
                    color: status.includes('✅') ? '#22c55e' : '#3b82f6',
                    borderRadius: '8px',
                    fontWeight: '500',
                    minHeight: '48px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                    {status}
                </div>

                {showPassword && (
                    <div style={{ marginBottom: '16px' }}>
                        <input
                            type="password"
                            placeholder="Optional: Helper Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={{ width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ccc' }}
                        />
                    </div>
                )}

                <button
                    onClick={verifyFace}
                    disabled={isLoading || !modelsLoaded}
                    className="btn btn-primary btn-lg"
                    style={{ width: '100%', marginBottom: '12px' }}
                >
                    {isLoading ? 'Verifying...' : 'Verify Helper Face'}
                </button>

                <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                        onClick={() => setShowPassword(!showPassword)}
                        className="btn btn-outline"
                        style={{ flex: 1, fontSize: '0.9rem' }}
                    >
                        {showPassword ? 'Hide Password' : 'Add Password'}
                    </button>
                    <button
                        onClick={handleSkip}
                        className="btn btn-outline"
                        style={{ flex: 1, fontSize: '0.9rem', color: '#f59e0b', borderColor: '#f59e0b' }}
                    >
                        Helper Missing? (Skip)
                    </button>
                </div>

            </div>
        </div>
    );
};

export default HelperCheckoutPage;
